<?php

// Inclure les fichiers nécessaires
require_once 'models/Country.php';
require_once 'models/Region.php';
require_once 'models/surveillance.php';
require_once 'models/Agent.php';
require_once 'controllers/CountryController.php';
require_once 'controllers/RegionController.php';
require_once 'controllers/SurveillancePointController.php';
require_once 'controllers/AgentController.php';

// Récupérer les paramètres de la requête
$action = isset($_GET['action']) ? $_GET['action'] : 'index';

// Instancier le contrôleur correspondant à l'action
switch ($action) {
    case 'index':
        $controller = new CountryController();
        break;
    case 'regions':
        $controller = new RegionController();
        break;
    case 'points':
        $controller = new SurveillancePointController();
        break;
    case 'agents':
        $controller = new AgentController();
        break;
    default:
        header('HTTP/1.1 404 Not Found');
        exit();
}

// Exécuter l'action correspondante
$controller->$action();
