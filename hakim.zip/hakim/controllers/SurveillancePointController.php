<?php

require_once('models/SurveillancePoint.php');
require_once('models/Region.php');

class SurveillancePointController {
    public function index() {
        $points = SurveillancePoint::all();
        require_once('views/points.php');
    }

    public function create() {
        $regions = Region::all();
        require_once('views/point-create.php');
    }

    public function store() {
        if (isset($_POST['name']) && isset($_POST['region_id']) && isset($_POST['population'])) {
            $point = new SurveillancePoint(null, $_POST['name'], $_POST['population'], $_POST['region_id']);
            $point->save();
            header('Location: index.php?controller=surveillance-point&action=index');
        } else {
            header('Location: index.php?controller=surveillance-point&action=create');
        }
    }

    public function edit() {
        if (isset($_GET['id'])) {
            $point = SurveillancePoint::find($_GET['id']);
            $regions = Region::all();
            require_once('views/point-edit.php');
        } else {
            header('Location: index.php?controller=surveillance-point&action=index');
        }
    }

    public function update() {
        if (isset($_POST['id']) && isset($_POST['name']) && isset($_POST['region_id']) && isset($_POST['population'])) {
            $point = SurveillancePoint::find($_POST['id']);
            $point->name = $_POST['name'];
            $point->population = $_POST['population'];
            $point->region_id = $_POST['region_id'];
            $point->save();
            header('Location: index.php?controller=surveillance-point&action=index');
        } else {
            header('Location: index.php?controller=surveillance-point&action=edit&id=' . $_POST['id']);
        }
    }

    public function destroy() {
        if (isset($_GET['id'])) {
            $point = SurveillancePoint::find($_GET['id']);
            $point->delete();
            header('Location: index.php?controller=surveillance-point&action=index');
        } else {
            header('Location: index.php?controller=surveillance-point&action=index');
        }
    }
}

?>
