<?php

require_once('models/Agent.php');

class AgentController {
  
  // Affiche la liste des agents
  public function index() {
    $agents = Agent::getAll();
    require_once('views/agent/index.php');
  }
  
  // Affiche le formulaire d'ajout d'un agent
  public function add() {
    require_once('views/agent/add.php');
  }
  
  // Ajoute un nouvel agent
  public function create() {
    if (isset($_POST['firstname']) && isset($_POST['lastname']) && isset($_POST['email']) && isset($_POST['password'])) {
      $agent = new Agent(null, $_POST['firstname'], $_POST['lastname'], $_POST['email'], $_POST['password']);
      $agent->save();
      header('Location: index.php?controller=agent&action=index');
    }
  }
  
  // Affiche le formulaire de modification d'un agent
  public function edit() {
    if (isset($_GET['id'])) {
      $agent = Agent::getById($_GET['id']);
      if ($agent) {
        require_once('views/agent/edit.php');
      } else {
        header('Location: index.php?controller=agent&action=index');
      }
    } else {
      header('Location: index.php?controller=agent&action=index');
    }
  }
  
  // Met à jour les informations d'un agent
  public function update() {
    if (isset($_POST['id']) && isset($_POST['firstname']) && isset($_POST['lastname']) && isset($_POST['email']) && isset($_POST['password'])) {
      $agent = Agent::getById($_POST['id']);
      if ($agent) {
        $agent->setFirstName($_POST['firstname']);
        $agent->setLastName($_POST['lastname']);
        $agent->setEmail($_POST['email']);
        $agent->setPassword($_POST['password']);
        $agent->save();
      }
      header('Location: index.php?controller=agent&action=index');
    }
  }
  
  // Supprime un agent
  public function delete() {
    if (isset($_GET['id'])) {
      $agent = Agent::getById($_GET['id']);
      if ($agent) {
        $agent->delete();
      }
    }
    header('Location: index.php?controller=agent&action=index');
  }
  
}
