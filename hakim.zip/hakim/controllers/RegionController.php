<?php

require_once 'models/Region.php';
require_once 'models/Country.php';
require_once 'models/SurveillancePoint.php';

class RegionController {
    
    public function index() {
        // récupérer la liste des régions
        $regions = Region::getAll();
        // afficher la vue des régions avec les données
        include 'views/regions.php';
    }
    
    public function create() {
        // récupérer la liste des pays
        $countries = Country::getAll();
        // afficher la vue de création de région avec les données
        include 'views/create_region.php';
    }
    
    public function store() {
        // récupérer les données du formulaire
        $name = $_POST['name'];
        $country_id = $_POST['country_id'];
        // créer la nouvelle région
        $region = new Region($name, $country_id);
        $region->save();
        // rediriger vers la liste des régions
        header('Location: index.php?controller=region&action=index');
    }
    
    public function edit() {
        // récupérer l'identifiant de la région à éditer
        $id = $_GET['id'];
        // récupérer la région correspondante
        $region = Region::getById($id);
        // récupérer la liste des pays
        $countries = Country::getAll();
        // afficher la vue d'édition de région avec les données
        include 'views/edit_region.php';
    }
    
    public function update() {
        // récupérer les données du formulaire
        $id = $_POST['id'];
        $name = $_POST['name'];
        $country_id = $_POST['country_id'];
        // mettre à jour la région correspondante
        $region = Region::getById($id);
        $region->setName($name);
        $region->setCountryId($country_id);
        $region->save();
        // rediriger vers la liste des régions
        header('Location: index.php?controller=region&action=index');
    }
    
    public function delete() {
        // récupérer l'identifiant de la région à supprimer
        $id = $_GET['id'];
        // supprimer la région correspondante
        $region = Region::getById($id);
        $region->delete();
        // rediriger vers la liste des régions
        header('Location: index.php?controller=region&action=index');
    }
    
    public function show() {
        // récupérer l'identifiant de la région à afficher
        $id = $_GET['id'];
        // récupérer la région correspondante
        $region = Region::getById($id);
        // récupérer les points de surveillance de la région
        $surveillance_points = SurveillancePoint::getByRegionId($id);
        // afficher la vue détaillée de la région avec les données
        include 'views/show_region.php';
    }
    
}
