<?php
require_once 'models/Country.php';

class CountryController {
    public function index() {
        $countries = Country::all();
        require 'views/countries.php';
    }

    public function create() {
        require 'views/country_create.php';
    }

    public function store() {
        $country = new Country($_POST['name']);
        $country->save();
        header('Location: index.php?action=index');
    }

    public function edit() {
        $country = Country::find($_GET['id']);
        require 'views/country_edit.php';
    }

    public function update() {
        $country = Country::find($_POST['id']);
        $country->setName($_POST['name']);
        $country->save();
        header('Location: index.php?action=index');
    }

    public function delete() {
        $country = Country::find($_GET['id']);
        $country->delete();
        header('Location: index.php?action=index');
    }
}
