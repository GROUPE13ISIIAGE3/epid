<?php

require_once 'Model.php';

class SurveillancePoint extends Model
{
    protected $table = 'surveillance_points';
    protected $fillable = ['name', 'latitude', 'longitude', 'region_id'];

    public function region()
    {
        return $this->belongsTo('Region');
    }

    public function agents()
    {
        return $this->hasMany('Agent');
    }
}
