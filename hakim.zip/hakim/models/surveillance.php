<?php
class SurveillancePoint {
  private $id;
  private $name;
  private $latitude;
  private $longitude;
  private $regionId;

  public function __construct($id, $name, $latitude, $longitude, $regionId) {
    $this->id = $id;
    $this->name = $name;
    $this->latitude = $latitude;
    $this->longitude = $longitude;
    $this->regionId = $regionId;
  }

  public function getId() {
    return $this->id;
  }

  public function getName() {
    return $this->name;
  }

  public function getLatitude() {
    return $this->latitude;
  }

  public function getLongitude() {
    return $this->longitude;
  }

  public function getRegionId() {
    return $this->regionId;
  }

  public function setName($name) {
    $this->name = $name;
  }

  public function setLatitude($latitude) {
    $this->latitude = $latitude;
  }

  public function setLongitude($longitude) {
    $this->longitude = $longitude;
  }

  public function setRegionId($regionId) {
    $this->regionId = $regionId;
  }
}
