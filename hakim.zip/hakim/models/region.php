<?php

class Region {
    
    private $id;
    private $name;
    private $color;
    private $countryId;
    private $surveillancePoints;
    
    public function __construct($id, $name, $color, $countryId) {
        $this->id = $id;
        $this->name = $name;
        $this->color = $color;
        $this->countryId = $countryId;
        $this->surveillancePoints = array();
    }
    
    public function getId() {
        return $this->id;
    }
    
    public function getName() {
        return $this->name;
    }
    
    public function getColor() {
        return $this->color;
    }
    
    public function getCountryId() {
        return $this->countryId;
    }
    
    public function getSurveillancePoints() {
        return $this->surveillancePoints;
    }
    
    public function addSurveillancePoint($surveillancePoint) {
        array_push($this->surveillancePoints, $surveillancePoint);
    }
    
    public function removeSurveillancePoint($surveillancePointId) {
        $newSurveillancePoints = array();
        foreach ($this->surveillancePoints as $surveillancePoint) {
            if ($surveillancePoint->getId() != $surveillancePointId) {
                array_push($newSurveillancePoints, $surveillancePoint);
            }
        }
        $this->surveillancePoints = $newSurveillancePoints;
    }
    
    public function toArray() {
        $regionArray = array(
            "id" => $this->id,
            "name" => $this->name,
            "color" => $this->color,
            "countryId" => $this->countryId
        );
        $surveillancePointsArray = array();
        foreach ($this->surveillancePoints as $surveillancePoint) {
            array_push($surveillancePointsArray, $surveillancePoint->toArray());
        }
        $regionArray["surveillancePoints"] = $surveillancePointsArray;
        return $regionArray;
    }
}

?>
