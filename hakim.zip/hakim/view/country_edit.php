<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Modifier un pays</title>
</head>
<body>
    <h1>Modifier un pays</h1>

    <?php if ($error): ?>
        <p style="color: red"><?= $error ?></p>
    <?php endif ?>

    <form method="POST">
        <label for="name">Nom du pays:</label>
        <input type="text" name="name" id="name" value="<?= $country->getName() ?>" required><br>

        <label for="population">Population:</label>
        <input type="number" name="population" id="population" value="<?= $country->getPopulation() ?>" required><br>

        <button type="submit" name="submit">Enregistrer</button>
    </form>
</body>
</html>
