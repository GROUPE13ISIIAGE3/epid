<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Créer un nouveau pays</title>
</head>
<body>
    <h1>Créer un nouveau pays</h1>
    <form action="<?php echo URL_ROOT . 'country/store' ?>" method="post">
        <div>
            <label for="name">Nom :</label>
            <input type="text" id="name" name="name">
        </div>
        <div>
            <label for="population">Population :</label>
            <input type="number" id="population" name="population">
        </div>
        <div>
            <input type="submit" value="Créer">
        </div>
    </form>
</body>
</html>
