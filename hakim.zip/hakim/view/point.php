<!-- views/point/index.php -->
<h1>List of Surveillance Points</h1>

<p><a href="?controller=point&action=create">Add a new point</a></p>

<table>
  <thead>
    <tr>
      <th>Point Name</th>
      <th>Region</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($points as $point): ?>
    <tr>
      <td><?= $point->getName() ?></td>
      <td><?= $point->getRegion()->getName() ?></td>
      <td>
        <a href="?controller=point&action=show&id=<?= $point->getId() ?>">View</a> |
        <a href="?controller=point&action=edit&id=<?= $point->getId() ?>">Edit</a> |
        <a href="?controller=point&action=delete&id=<?= $point->getId() ?>">Delete</a>
      </td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>
