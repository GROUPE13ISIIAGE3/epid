<!-- views/agent/index.php -->

<h1>Liste des agents</h1>

<p><a href="?action=create">Ajouter un agent</a></p>

<table>
  <thead>
    <tr>
      <th>Nom</th>
      <th>Prénom</th>
      <th>Zone de surveillance</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($agents as $agent) { ?>
      <tr>
        <td><?= $agent->getLastname() ?></td>
        <td><?= $agent->getFirstname() ?></td>
        <td><?= $agent->getSurveillancePoint()->getRegion()->getName() ?> - <?= $agent->getSurveillancePoint()->getName() ?></td>
        <td>
          <a href="?action=edit&id=<?= $agent->getId() ?>">Modifier</a>
          <a href="?action=delete&id=<?= $agent->getId() ?>" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet agent ?')">Supprimer</a>
        </td>
      </tr>
    <?php } ?>
  </tbody>
</table>
