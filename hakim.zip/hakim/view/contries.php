<?php
// inclusion du header
include 'header.php';
?>

<h1>Liste des pays</h1>

<table>
  <thead>
    <tr>
      <th>Nom du pays</th>
      <th>Nombre de zones</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($countries as $country): ?>
      <tr>
        <td><?php echo $country->getName(); ?></td>
        <td><?php echo $country->getNumberOfRegions(); ?></td>
        <td>
          <a href="index.php?controller=region&action=index&country_id=<?php echo $country->getId(); ?>">Voir les zones</a>
          <a href="index.php?controller=country&action=edit&id=<?php echo $country->getId(); ?>">Modifier</a>
          <a href="index.php?controller=country&action=delete&id=<?php echo $country->getId(); ?>">Supprimer</a>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<a href="index.php?controller=country&action=create">Ajouter un pays</a>

<?php
// inclusion du footer
include 'footer.php';
?>
