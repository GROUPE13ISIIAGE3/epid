<?php
// Récupération de l'identifiant du pays
$country_id = $_GET['country_id'];

// Récupération de l'objet Country correspondant
$country = Country::find($country_id);

// Récupération de la liste des régions correspondant au pays
$regions = Region::findAllByCountryId($country_id);
?>

<h1>Régions de <?= $country->getName() ?></h1>

<p>Voici la liste des régions du pays <?= $country->getName() ?>:</p>

<ul>
  <?php foreach ($regions as $region): ?>
    <li><?= $region->getName() ?></li>
  <?php endforeach; ?>
</ul>

<p><a href="add_region.php?country_id=<?= $country_id ?>">Ajouter une région</a></p>
